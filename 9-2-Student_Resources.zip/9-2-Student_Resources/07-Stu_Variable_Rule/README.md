# Justice League API - Continued

* In this activity, you will add an additional API route that returns json for a Python Dictionary containing an individual superheroes information.

## Instructions

* Using the last activity as a starting point, add code to allow for getting a specific hero's information based on their superhero name.

- - -

### Copyright

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.
